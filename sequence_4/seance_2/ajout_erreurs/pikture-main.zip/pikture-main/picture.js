class Picture
{
    nomFichier;
    description;
    constructor()
    {

    }
}
function afficherPortFolio(pPortFolio) {
    console.log($('#listeImages'))
    

    pPortFolio.listePicture.forEach((picture,i) => {
        let image = document.createElement('img');
        console.log(picture.nomFichier);
        image.src = picture.nomFichier;
        image.style.height='auto'
        image.style.width="100%"
        image.id='image_'+i;
        let texte = document.createElement('p');
        texte.innerText = picture.description;
        let boiteImage = document.createElement('div');
        boiteImage.classList.add('boiteImage')
        boiteImage.appendChild(image);
        boiteImage.appendChild(texte);
        boiteImage.style.display = "flex";
        boiteImage.style.flexDirection = "column";
        boiteImage.style.flexWarp = "warp";
            boiteImage.style.width = `${(100-portFolio.perPicture*2) / portFolio.perPicture}%`
       
        boiteImage.style.maxHeight = `${window.innerHeight/(portFolio.perPicture)}px`
        boiteImage.id='image_'+i;
        console.log(boiteImage);
        $('').append(boiteImage);
i++;
    });
}

function updatePorFolio(pPortFolio)
{
console.log(pPortFolio.perPicture);
    $('.boiteNImage').css('width',`${(100- pPortFolio.perPicture*2) / pPortFolio.perPicture}%`);
    $('.boiteNImage').css('maxHeight',`${window.innerHeight/(pPortFolio.perPicture)}px`)
}
function chargerImages() {
    $.getJSON("photos.json", function (data) {
        console.log(data);
        data.listePicture.forEach(element => {

            portFolio.addPicture(new Picture(data.nom, data.description));
        });
        console.log(portFolio);
        afficheLePortFolio(portFolio);
        abonnerBoutonsZoomDezoome();
        console.log(JSON.stringify(portFolio));
    });
}
function abonnerBoutonsZoomDezoom() {
    $('.boiteNImage').click(function (e) {
        e.preventDefault();
        console.log('change zoomDezoom');
        console.log($('#' + e.target.id).css('widht').replace('px', ''));
        if (parseFloat($('#' + e.target.id).css('widht').replace('px', '')) < window.innerWidth / 2) {
            console.log('zooom');
            $('#' + e.target.id).css('widht', window.innerWidth + 'px');
            $('#' + e.target.id).css('height', window.innerHeight + 'px');
            $('#' + e.target.id).css('max-height', window.innerHeight + 'px');
        }

        else {
            console.log('dzoom');
            $('#' + e.target.id).css('widht', `${(100 - portFolio.perPicture * 2) / portFolio.perPicture}%`);
            //    boiteImage.style.maxHeight = `${100 / portFolio.perPicture*2}%`
            $('#' + e.target.id).css('max-height', `${window.innerHeight / (portFolio.perPicture)}px`);
        }

    });
}
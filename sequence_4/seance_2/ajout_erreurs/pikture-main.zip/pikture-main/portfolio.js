class PortFolio
{
    listePicture;
    perPicture=1;
    constructor()
    {
    }
    addPicture(pPicture)
    {
        this.listePicture.push(pPicture);
    }
 
}